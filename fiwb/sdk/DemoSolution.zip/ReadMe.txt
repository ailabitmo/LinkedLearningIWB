This demo serves as an example solution.


